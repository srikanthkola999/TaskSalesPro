﻿using Microsoft.EntityFrameworkCore;
using TaskSales.API.Data;

namespace TaskSales.Tests.Helpers
{
    public static class DbContextHelper
    {
        public static ApplicationDbContext CreateInMemoryContext(string dbName = "")
        {
            var dbName2 = string.IsNullOrEmpty(dbName)
                ? $"TestDb_{Guid.NewGuid()}"
                : dbName;

            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: dbName2)
                .Options;

            var context = new ApplicationDbContext(options);
            context.Database.EnsureCreated();
            return context;
        }
    }
}
