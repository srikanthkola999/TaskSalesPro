﻿using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Security.Claims;
using TaskSales.API.Controllers;
using TaskSales.API.DTOs;
using TaskSales.API.Entities;
using TaskSales.API.Interfaces;
using TaskSales.API.MongoDB;

namespace TaskSales.Tests.Controllers
{
    public class TasksControllerTests
    {
        private readonly Mock<ITaskRepository> _repoMock = new();
        private readonly Mock<IMongoActivityLogService> _logMock = new();

        private TasksController CreateController(string userId = "user-1", string role = "Admin")
        {
            var ctrl = new TasksController(_repoMock.Object, _logMock.Object);
            ctrl.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext
                {
                    User = new ClaimsPrincipal(new ClaimsIdentity(new[]
                    {
                        new Claim(ClaimTypes.NameIdentifier, userId),
                        new Claim(ClaimTypes.Role, role)
                    }, "Test"))
                }
            };
            // Fire-and-forget log never throws
            _logMock.Setup(l => l.LogAsync(It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>()))
                .Returns(Task.CompletedTask);
            return ctrl;
        }

        // ── GetAll ────────────────────────────────────────────
        [Fact]
        public async Task GetAll_ReturnsOkWithTasks()
        {
            var tasks = new List<TaskItem>
            {
                new() { TaskId=1, Title="T1", Status=AppTaskStatus.Pending,
                        Priority=AppTaskPriority.Medium, AssignedEmployee=new Employee{Name="Alice"} },
                new() { TaskId=2, Title="T2", Status=AppTaskStatus.Completed,
                        Priority=AppTaskPriority.High,   AssignedEmployee=new Employee{Name="Bob"} }
            };
            _repoMock.Setup(r => r.GetAllAsync()).ReturnsAsync(tasks);
            var ctrl = CreateController();

            var result = await ctrl.GetAll();

            var ok = result.Should().BeOfType<OkObjectResult>().Subject;
            var data = (ok.Value as IEnumerable<TaskDto>)!.ToList();
            data.Should().HaveCount(2);
            data[0].Title.Should().Be("T1");
            data[0].Status.Should().Be("Pending");
            data[1].EmployeeName.Should().Be("Bob");
        }

        // ── GetById ───────────────────────────────────────────
        [Fact]
        public async Task GetById_ValidId_ReturnsOk()
        {
            var task = new TaskItem
            {
                TaskId = 1,
                Title = "Test",
                Status = AppTaskStatus.Pending,
                Priority = AppTaskPriority.Low,
                AssignedEmployee = new Employee { Name = "Carol" }
            };
            _repoMock.Setup(r => r.GetByIdAsync(1)).ReturnsAsync(task);
            var ctrl = CreateController();

            var result = await ctrl.GetById(1);

            result.Should().BeOfType<OkObjectResult>();
        }

        [Fact]
        public async Task GetById_InvalidId_ReturnsNotFound()
        {
            _repoMock.Setup(r => r.GetByIdAsync(999)).ReturnsAsync((TaskItem?)null);
            var ctrl = CreateController();

            var result = await ctrl.GetById(999);

            result.Should().BeOfType<NotFoundResult>();
        }

        // ── Create ────────────────────────────────────────────
        [Fact]
        public async Task Create_ValidDto_ReturnsCreatedAtAction()
        {
            var dto = new CreateTaskDto
            {
                Title = "New Task",
                Status = "Pending",
                Priority = "Medium",
                AssignedEmployeeId = 1,
                DueDate = DateTime.UtcNow.AddDays(7)
            };
            var saved = new TaskItem
            {
                TaskId = 10,
                Title = "New Task",
                AssignedEmployee = new Employee { Name = "Dave" }
            };
            _repoMock.Setup(r => r.AddAsync(It.IsAny<TaskItem>())).ReturnsAsync(saved);
            var ctrl = CreateController();

            var result = await ctrl.Create(dto);

            var created = result.Should().BeOfType<CreatedAtActionResult>().Subject;
            created.RouteValues!["id"].Should().Be(10);
        }

        // ── Update ────────────────────────────────────────────
        [Fact]
        public async Task Update_ValidId_ReturnsNoContent()
        {
            var task = new TaskItem
            {
                TaskId = 1,
                Title = "Old",
                Status = AppTaskStatus.Pending,
                Priority = AppTaskPriority.Low
            };
            _repoMock.Setup(r => r.GetByIdAsync(1)).ReturnsAsync(task);
            _repoMock.Setup(r => r.UpdateAsync(It.IsAny<TaskItem>())).Returns(Task.CompletedTask);
            var dto = new CreateTaskDto
            {
                Title = "Updated",
                Status = "InProgress",
                Priority = "High",
                AssignedEmployeeId = 1,
                DueDate = DateTime.UtcNow.AddDays(14)
            };
            var ctrl = CreateController();

            var result = await ctrl.Update(1, dto);

            result.Should().BeOfType<NoContentResult>();
        }

        [Fact]
        public async Task Update_InvalidId_ReturnsNotFound()
        {
            _repoMock.Setup(r => r.GetByIdAsync(999)).ReturnsAsync((TaskItem?)null);
            var ctrl = CreateController();

            var result = await ctrl.Update(999, new CreateTaskDto
            {
                Title = "X",
                Status = "Pending",
                Priority = "Low",
                AssignedEmployeeId = 1,
                DueDate = DateTime.UtcNow
            });

            result.Should().BeOfType<NotFoundResult>();
        }

        // ── Delete ────────────────────────────────────────────
        [Fact]
        public async Task Delete_ValidId_ReturnsNoContent()
        {
            _repoMock.Setup(r => r.DeleteAsync(1)).Returns(Task.CompletedTask);
            var ctrl = CreateController();

            var result = await ctrl.Delete(1);

            result.Should().BeOfType<NoContentResult>();
        }
    }
}
