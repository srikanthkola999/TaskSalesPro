﻿//using FluentAssertions;
//using Microsoft.AspNetCore.Mvc;
//using Moq;
//using TaskSales.API.Controllers;
//using TaskSales.API.DTOs;
//using TaskSales.API.Entities;
//using TaskSales.API.Interfaces;
//using TaskSales.API.MongoDB;

//namespace TaskSales.Tests.Controllers
//{
//    public class SalesControllerTests
//    {
//        private readonly Mock<ISaleRepository> _repoMock = new();
//        private readonly Mock<IMongoActivityLogService> _logMock = new();

//        private SalesController CreateController()
//        {
//            _logMock.Setup(l => l.LogAsync(It.IsAny<string>(), It.IsAny<string>(),
//                It.IsAny<string>(), It.IsAny<string>()))
//                .Returns(Task.CompletedTask);
//            return new SalesController(_repoMock.Object, _logMock.Object);
//        }

//        [Fact]
//        public async Task GetAll_ReturnsSalesWithEmployeeNames()
//        {
//            _repoMock.Setup(r => r.GetAllAsync()).ReturnsAsync(new List<Sale>
//            {
//                new() { SaleId=1, ProductName="Laptop", Category="Electronics",
//                        Amount=1200, Employee=new Employee{Name="Alice"} },
//                new() { SaleId=2, ProductName="SaaS",   Category="Software",
//                        Amount=500,  Employee=new Employee{Name="Bob"} }
//            });

//            var result = await CreateController().GetAll();

//            var ok = result.Should().BeOfType<OkObjectResult>().Subject;
//            var data = (ok.Value as IEnumerable<SaleDto>)!.ToList();
//            data.Should().HaveCount(2);
//            data[0].EmployeeName.Should().Be("Alice");
//            data[1].Category.Should().Be("Software");
//        }

//        [Fact]
//        public async Task ByCategory_ReturnsGroupedSummary()
//        {
//            _repoMock.Setup(r => r.GetSalesByCategoryAsync()).ReturnsAsync(new List<SalesSummary>
//            {
//                new("Electronics", 1500, 3),
//                new("Software",    800,  2)
//            });

//            var result = await CreateController().ByCategory();

//            var ok = result.Should().BeOfType<OkObjectResult>().Subject;
//            var data = (ok.Value as IEnumerable<SalesSummary>)!.ToList();
//            data.Should().HaveCount(2);
//            data[0].Total.Should().Be(1500);
//        }

//        [Fact]
//        public async Task Monthly_ReturnsCorrectYear()
//        {
//            var year = DateTime.Now.Year;
//            _repoMock.Setup(r => r.GetMonthlySalesAsync(year)).ReturnsAsync(new List<MonthlySalesSummary>
//            {
//                new(1, "Jan", 1000),
//                new(2, "Feb", 2000)
//            });

//            var result = await CreateController().Monthly(year);

//            var ok = result.Should().BeOfType<OkObjectResult>().Subject;
//            var data = (ok.Value as IEnumerable<MonthlySalesSummary>)!.ToList();
//            data.Should().HaveCount(2);
//            data[1].MonthName.Should().Be("Feb");
//        }

//        [Fact]
//        public async Task Create_ValidDto_ReturnsCreated()
//        {
//            var dto = new CreateSaleDto
//            {
//                ProductName = "Laptop",
//                Category = "Electronics",
//                Amount = 1200,
//                EmployeeId = 1,
//                SaleDate = DateTime.UtcNow
//            };
//            var sale = new Sale { SaleId = 5, ProductName = "Laptop", Employee = new Employee { Name = "Alice" } };
//            _repoMock.Setup(r => r.AddAsync(It.IsAny<Sale>())).ReturnsAsync(sale);

//            var result = await CreateController().Create(dto);

//            result.Should().BeOfType<CreatedAtActionResult>();
//        }
//    }
//}
