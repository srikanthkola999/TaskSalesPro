﻿using FluentAssertions;
using TaskSales.API.Entities;
using TaskSales.API.Repositories;
using TaskSales.Tests.Helpers;

namespace TaskSales.Tests.Repositories
{
    public class EmployeeRepositoryTests
    {
        // ── GetAllAsync ────────────────────────────────────────
        [Fact]
        public async Task GetAllAsync_ReturnsAllEmployees()
        {
            // Arrange
            using var ctx = DbContextHelper.CreateInMemoryContext();
            ctx.Employees.AddRange(
                new Employee { Name = "Alice", Email = "alice@test.com", Department = "IT", Role = "Employee" },
                new Employee { Name = "Bob", Email = "bob@test.com", Department = "Sales", Role = "Employee" },
                new Employee { Name = "Carol", Email = "carol@test.com", Department = "Admin", Role = "Admin" }
            );
            await ctx.SaveChangesAsync();
            var repo = new EmployeeRepository(ctx);

            // Act
            var result = await repo.GetAllAsync();

            // Assert
            result.Should().HaveCount(3);
            result.Select(e => e.Name).Should().Contain(new[] { "Alice", "Bob", "Carol" });
        }

        [Fact]
        public async Task GetAllAsync_EmptyDatabase_ReturnsEmptyList()
        {
            using var ctx = DbContextHelper.CreateInMemoryContext();
            var repo = new EmployeeRepository(ctx);

            var result = await repo.GetAllAsync();

            result.Should().BeEmpty();
        }

        // ── GetByIdAsync ───────────────────────────────────────
        [Fact]
        public async Task GetByIdAsync_ValidId_ReturnsEmployee()
        {
            using var ctx = DbContextHelper.CreateInMemoryContext();
            var emp = new Employee { Name = "Alice", Email = "alice@test.com", Role = "Employee" };
            ctx.Employees.Add(emp);
            await ctx.SaveChangesAsync();
            var repo = new EmployeeRepository(ctx);

            var result = await repo.GetByIdAsync(emp.EmployeeId);

            result.Should().NotBeNull();
            result!.Name.Should().Be("Alice");
        }

        [Fact]
        public async Task GetByIdAsync_InvalidId_ReturnsNull()
        {
            using var ctx = DbContextHelper.CreateInMemoryContext();
            var repo = new EmployeeRepository(ctx);

            var result = await repo.GetByIdAsync(9999);

            result.Should().BeNull();
        }

        // ── AddAsync ───────────────────────────────────────────
        [Fact]
        public async Task AddAsync_ValidEmployee_SavesAndReturns()
        {
            using var ctx = DbContextHelper.CreateInMemoryContext();
            var repo = new EmployeeRepository(ctx);
            var emp = new Employee
            {
                Name = "Dave",
                Email = "dave@test.com",
                Department = "HR",
                Role = "Employee"
            };

            var result = await repo.AddAsync(emp);

            result.EmployeeId.Should().BeGreaterThan(0);
            result.Name.Should().Be("Dave");
            ctx.Employees.Count().Should().Be(1);
        }

        // ── UpdateAsync ────────────────────────────────────────
        [Fact]
        public async Task UpdateAsync_ChangesName_PersistsUpdate()
        {
            using var ctx = DbContextHelper.CreateInMemoryContext();
            var emp = new Employee { Name = "Eve", Email = "eve@test.com", Role = "Employee" };
            ctx.Employees.Add(emp);
            await ctx.SaveChangesAsync();
            var repo = new EmployeeRepository(ctx);

            emp.Name = "Eve Updated";
            await repo.UpdateAsync(emp);

            var updated = await ctx.Employees.FindAsync(emp.EmployeeId);
            updated!.Name.Should().Be("Eve Updated");
        }

        // ── DeleteAsync ────────────────────────────────────────
        [Fact]
        public async Task DeleteAsync_ValidId_RemovesEmployee()
        {
            using var ctx = DbContextHelper.CreateInMemoryContext();
            var emp = new Employee { Name = "Frank", Email = "frank@test.com", Role = "Employee" };
            ctx.Employees.Add(emp);
            await ctx.SaveChangesAsync();
            var repo = new EmployeeRepository(ctx);

            await repo.DeleteAsync(emp.EmployeeId);

            ctx.Employees.Count().Should().Be(0);
        }

        [Fact]
        public async Task DeleteAsync_InvalidId_DoesNotThrow()
        {
            using var ctx = DbContextHelper.CreateInMemoryContext();
            var repo = new EmployeeRepository(ctx);

            Func<Task> act = () => repo.DeleteAsync(9999);

            await act.Should().NotThrowAsync();
        }

        // ── GetByEmailAsync ────────────────────────────────────
        [Fact]
        public async Task GetByEmailAsync_ExistingEmail_ReturnsEmployee()
        {
            using var ctx = DbContextHelper.CreateInMemoryContext();
            ctx.Employees.Add(new Employee { Name = "Grace", Email = "grace@test.com", Role = "Employee" });
            await ctx.SaveChangesAsync();
            var repo = new EmployeeRepository(ctx);

            var result = await repo.GetByEmailAsync("grace@test.com");

            result.Should().NotBeNull();
            result!.Name.Should().Be("Grace");
        }

        [Fact]
        public async Task GetByEmailAsync_NotExistingEmail_ReturnsNull()
        {
            using var ctx = DbContextHelper.CreateInMemoryContext();
            var repo = new EmployeeRepository(ctx);

            var result = await repo.GetByEmailAsync("nobody@test.com");

            result.Should().BeNull();
        }
    }
}
