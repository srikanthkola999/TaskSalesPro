﻿using Microsoft.AspNetCore.Components.Authorization;
using System.Net.Http.Json;
using TaskSales.BlazorUI.Models;

namespace TaskSales.BlazorUI.Services
{
    public interface IAuthService
    {
        Task<(bool Ok, string Msg)> LoginAsync(LoginModel m);
        Task<(bool Ok, string Msg)> RegisterAsync(RegisterModel m);
        Task LogoutAsync();
    }

    public class AuthService(IHttpClientFactory factory, AuthenticationStateProvider asp) : IAuthService
    {
        private readonly HttpClient _http = factory.CreateClient("API");
        private readonly CookieAuthStateProvider _state = (CookieAuthStateProvider)asp;

        public async Task<(bool Ok, string Msg)> LoginAsync(LoginModel m)
        {
            var r = await _http.PostAsJsonAsync("api/auth/login",
                new { m.Email, m.Password, RememberMe = false });
            if (r.IsSuccessStatusCode) { _state.NotifyChanged(); return (true, ""); }
            return (false, "Invalid email or password");
        }

        public async Task<(bool Ok, string Msg)> RegisterAsync(RegisterModel m)
        {
            var r = await _http.PostAsJsonAsync("api/auth/register",
                new { m.FullName, m.Email, m.Password, m.Role, m.Department });
            if (r.IsSuccessStatusCode) return (true, "Registration successful!");
            return (false, await r.Content.ReadAsStringAsync());
        }

        public async Task LogoutAsync()
        { await _http.PostAsync("api/auth/logout", null); _state.NotifyChanged(); }
    }
}
