﻿using System.Net.Http.Json;
using TaskSales.BlazorUI.Models;

namespace TaskSales.BlazorUI.Services
{
    public interface IApiService
    {
        Task<List<EmployeeModel>> GetEmployeesAsync();
        Task<bool> CreateEmployeeAsync(CreateEmployeeModel m);
        Task<bool> UpdateEmployeeAsync(int id, CreateEmployeeModel m);
        Task<bool> DeleteEmployeeAsync(int id);

        Task<List<TaskModel>> GetTasksAsync();
        Task<List<TaskModel>> GetTasksByEmployeeAsync(int empId);
        Task<bool> CreateTaskAsync(CreateTaskModel m);
        Task<bool> UpdateTaskAsync(int id, CreateTaskModel m);
        Task<bool> DeleteTaskAsync(int id);

        Task<List<SaleModel>> GetSalesAsync();
        Task<List<SaleModel>> GetSalesByEmployeeAsync(int empId);
        Task<bool> CreateSaleAsync(CreateSaleModel m);
        Task<bool> UpdateSaleAsync(int id, CreateSaleModel m);
        Task<bool> DeleteSaleAsync(int id);
        Task<List<SalesSummaryModel>> GetSalesByCategoryAsync();
        Task<List<MonthlySalesModel>> GetMonthlySalesAsync(int year);
        Task<List<EmployeeSalesModel>> GetSalesByEmployeeAnalyticsAsync();

        Task<List<ActivityLogModel>> GetLogsAsync(int limit = 200);

        // Reviews
        Task<bool> AddReviewAsync(AddReviewModel m);
        Task<List<ReviewModel>> GetReviewsByTaskAsync(int taskId);
        Task<bool> HasReviewedAsync(int taskId, int employeeId);
    }

    public class ApiService : IApiService
    {
        private readonly IHttpClientFactory _factory;

        public ApiService(IHttpClientFactory factory)
        {
            _factory = factory;
        }

        // Creates a fresh client per call — ensures CookieForwardingHandler
        // always has the current HttpContext with the latest cookie
        private HttpClient Client => _factory.CreateClient("API");

        // ── Employees ─────────────────────────────────────────────
        public async Task<List<EmployeeModel>> GetEmployeesAsync()
            => await Client.GetFromJsonAsync<List<EmployeeModel>>("api/employees")
               ?? new List<EmployeeModel>();

        public async Task<bool> CreateEmployeeAsync(CreateEmployeeModel m)
            => (await Client.PostAsJsonAsync("api/employees", m)).IsSuccessStatusCode;

        public async Task<bool> UpdateEmployeeAsync(int id, CreateEmployeeModel m)
            => (await Client.PutAsJsonAsync($"api/employees/{id}", m)).IsSuccessStatusCode;

        public async Task<bool> DeleteEmployeeAsync(int id)
            => (await Client.DeleteAsync($"api/employees/{id}")).IsSuccessStatusCode;

        // ── Tasks ─────────────────────────────────────────────────
        public async Task<List<TaskModel>> GetTasksAsync()
            => await Client.GetFromJsonAsync<List<TaskModel>>("api/tasks")
               ?? new List<TaskModel>();

        public async Task<List<TaskModel>> GetTasksByEmployeeAsync(int empId)
            => await Client.GetFromJsonAsync<List<TaskModel>>($"api/tasks/employee/{empId}")
               ?? new List<TaskModel>();

        public async Task<bool> CreateTaskAsync(CreateTaskModel m)
        {
            var response = await Client.PostAsJsonAsync("api/tasks", new
            {
                m.Title,
                m.Description,
                m.Status,
                m.Priority,
                m.AssignedEmployeeId,
                m.DueDate
            });
            if (!response.IsSuccessStatusCode)
                Console.WriteLine("CreateTask failed: " + response.StatusCode
                    + " — " + await response.Content.ReadAsStringAsync());
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> UpdateTaskAsync(int id, CreateTaskModel m)
        {
            var response = await Client.PutAsJsonAsync($"api/tasks/{id}", new
            {
                m.Title,
                m.Description,
                m.Status,
                m.Priority,
                m.AssignedEmployeeId,
                m.DueDate
            });
            if (!response.IsSuccessStatusCode)
                Console.WriteLine("UpdateTask failed: " + response.StatusCode
                    + " — " + await response.Content.ReadAsStringAsync());
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> DeleteTaskAsync(int id)
            => (await Client.DeleteAsync($"api/tasks/{id}")).IsSuccessStatusCode;

        // ── Sales ─────────────────────────────────────────────────
        public async Task<List<SaleModel>> GetSalesAsync()
            => await Client.GetFromJsonAsync<List<SaleModel>>("api/sales")
               ?? new List<SaleModel>();

        public async Task<List<SaleModel>> GetSalesByEmployeeAsync(int empId)
            => await Client.GetFromJsonAsync<List<SaleModel>>($"api/sales/employee/{empId}")
               ?? new List<SaleModel>();

        public async Task<bool> CreateSaleAsync(CreateSaleModel m)
            => (await Client.PostAsJsonAsync("api/sales", m)).IsSuccessStatusCode;

        public async Task<bool> UpdateSaleAsync(int id, CreateSaleModel m)
            => (await Client.PutAsJsonAsync($"api/sales/{id}", m)).IsSuccessStatusCode;

        public async Task<bool> DeleteSaleAsync(int id)
            => (await Client.DeleteAsync($"api/sales/{id}")).IsSuccessStatusCode;

        public async Task<List<SalesSummaryModel>> GetSalesByCategoryAsync()
        {
            try
            {
                return await Client.GetFromJsonAsync<List<SalesSummaryModel>>(
                    "api/sales/analytics/by-category") ?? new List<SalesSummaryModel>();
            }
            catch { return new List<SalesSummaryModel>(); }
        }

        public async Task<List<MonthlySalesModel>> GetMonthlySalesAsync(int year)
        {
            try
            {
                return await Client.GetFromJsonAsync<List<MonthlySalesModel>>(
                    $"api/sales/analytics/monthly/{year}") ?? new List<MonthlySalesModel>();
            }
            catch { return new List<MonthlySalesModel>(); }
        }

        public async Task<List<EmployeeSalesModel>> GetSalesByEmployeeAnalyticsAsync()
        {
            try
            {
                return await Client.GetFromJsonAsync<List<EmployeeSalesModel>>(
                    "api/sales/analytics/by-employee") ?? new List<EmployeeSalesModel>();
            }
            catch { return new List<EmployeeSalesModel>(); }
        }

        // ── Logs ──────────────────────────────────────────────────
        public async Task<List<ActivityLogModel>> GetLogsAsync(int limit = 200)
        {
            try
            {
                return await Client.GetFromJsonAsync<List<ActivityLogModel>>(
                    $"api/logs?limit={limit}") ?? new List<ActivityLogModel>();
            }
            catch { return new List<ActivityLogModel>(); }
        }

        // ── Reviews ───────────────────────────────────────────────
        public async Task<bool> AddReviewAsync(AddReviewModel m)
        {
            var response = await Client.PostAsJsonAsync("api/reviews", new
            {
                m.TaskId,
                m.EmployeeId,
                m.Rating,
                m.Comment
            });
            if (!response.IsSuccessStatusCode)
                Console.WriteLine("AddReview failed: " + response.StatusCode);
            return response.IsSuccessStatusCode;
        }

        public async Task<List<ReviewModel>> GetReviewsByTaskAsync(int taskId)
        {
            try
            {
                return await Client.GetFromJsonAsync<List<ReviewModel>>(
                    "api/reviews/task/" + taskId) ?? new List<ReviewModel>();
            }
            catch { return new List<ReviewModel>(); }
        }

        public async Task<bool> HasReviewedAsync(int taskId, int employeeId)
        {
            try
            {
                var result = await Client.GetFromJsonAsync<HasReviewedResponse>(
                    $"api/reviews/check/{taskId}/{employeeId}");
                return result?.HasReviewed ?? false;
            }
            catch { return false; }
        }

        private class HasReviewedResponse
        {
            public bool HasReviewed { get; set; }
        }
    }
}