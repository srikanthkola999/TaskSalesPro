﻿using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Http;
using System.Net.Http.Json;
using System.Security.Claims;

namespace TaskSales.BlazorUI.Services
{
    public class CookieAuthStateProvider : AuthenticationStateProvider
    {
        private readonly IHttpClientFactory _factory;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public CookieAuthStateProvider(
            IHttpClientFactory factory,
            IHttpContextAccessor httpContextAccessor)
        {
            _factory = factory;
            _httpContextAccessor = httpContextAccessor;
        }

        public override async Task<AuthenticationState> GetAuthenticationStateAsync()
        {
            try
            {
                var client = _factory.CreateClient("API");

                // ✅ Manually forward the browser cookie to the API call
                var httpContext = _httpContextAccessor.HttpContext;
                if (httpContext != null)
                {
                    var cookieHeader = httpContext.Request.Headers["Cookie"].ToString();
                    if (!string.IsNullOrEmpty(cookieHeader))
                    {
                        client.DefaultRequestHeaders.Remove("Cookie");
                        client.DefaultRequestHeaders.Add("Cookie", cookieHeader);
                    }
                }

                var me = await client.GetFromJsonAsync<MeResponse>("api/auth/me");
                if (me?.Email == null)
                    return Anonymous();

                var claims = new List<Claim>
                {
                    new(ClaimTypes.Name,  me.Email),
                    new(ClaimTypes.Email, me.Email),
                    new("FullName", me.FullName ?? ""),
                };

                foreach (var role in me.Roles ?? new List<string>())
                    claims.Add(new Claim(ClaimTypes.Role, role));

                if (me.EmployeeId.HasValue)
                    claims.Add(new Claim("EmployeeId", me.EmployeeId.Value.ToString()));

                var identity = new ClaimsIdentity(claims, "CookieAuth");
                return new AuthenticationState(new ClaimsPrincipal(identity));
            }
            catch
            {
                return Anonymous();
            }
        }

        public void NotifyChanged()
            => NotifyAuthenticationStateChanged(GetAuthenticationStateAsync());

        private static AuthenticationState Anonymous()
            => new(new ClaimsPrincipal(new ClaimsIdentity()));

        private record MeResponse(
            string? Email,
            string? FullName,
            List<string>? Roles,
            int? EmployeeId);
    }
}