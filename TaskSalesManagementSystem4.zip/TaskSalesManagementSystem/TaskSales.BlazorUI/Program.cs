using Microsoft.AspNetCore.Components.Authorization;
using Syncfusion.Blazor;
using TaskSales.BlazorUI.Services;

var builder = WebApplication.CreateBuilder(args);

Syncfusion.Licensing.SyncfusionLicenseProvider.RegisterLicense(
    builder.Configuration["Syncfusion:LicenseKey"] ?? "");

builder.Services.AddRazorPages();     // ✅ needed for DoLogin.cshtml
builder.Services.AddServerSideBlazor();
builder.Services.AddSyncfusionBlazor();
builder.Services.AddHttpContextAccessor();
builder.Services.AddAntiforgery();    // ✅ needed for form POST security

builder.Services.AddScoped<AuthenticationStateProvider, CookieAuthStateProvider>();
builder.Services.AddAuthorizationCore();

builder.Services.AddScoped<CookieForwardingHandler>();

builder.Services.AddHttpClient("API", c =>
    c.BaseAddress = new Uri(builder.Configuration["ApiBaseUrl"] ?? "https://localhost:7008/"))
    .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
    {
        UseCookies = false,
        AllowAutoRedirect = false
    })
    .AddHttpMessageHandler<CookieForwardingHandler>();

builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<IApiService, ApiService>();

var app = builder.Build();

app.UseStaticFiles();
app.UseRouting();
//app.UseAntiforgery();    // ✅ must be before MapRazorPages
//app.MapRazorPages();     // ✅ enables /do-login endpoint
app.MapRazorPages();     // ✅ keep — enables /do-login
app.MapBlazorHub();
app.MapFallbackToPage("/_Host");
app.Run();
