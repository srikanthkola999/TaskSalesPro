using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TaskSales.BlazorUI.Pages
{
    [IgnoreAntiforgeryToken]
    public class DoLoginModel : PageModel
    {
        private readonly IHttpClientFactory _factory;
        private readonly IConfiguration _config;

        public DoLoginModel(IHttpClientFactory factory, IConfiguration config)
        {
            _factory = factory;
            _config = config;
        }

        public async Task<IActionResult> OnPostAsync(
            [FromForm] string email,
            [FromForm] string password)
        {
            try
            {
                var client = _factory.CreateClient("API");

                var response = await client.PostAsJsonAsync("api/auth/login", new
                {
                    Email = email,
                    Password = password,
                    RememberMe = true
                });

                if (!response.IsSuccessStatusCode)
                    return Redirect("/login?error=1");

                // ✅ Forward Set-Cookie from API response to browser
                // Use TryGetValues — no Regex, no @"" verbatim strings needed
                if (response.Headers.TryGetValues("Set-Cookie", out var cookies))
                {
                    foreach (var cookie in cookies)
                    {
                        // Strip Domain= segment using simple string split
                        // Cannot use @"regex" in .cshtml.cs — Razor parses the @
                        var parts = cookie.Split(';');
                        var cleanParts = new List<string>();
                        foreach (var part in parts)
                        {
                            var trimmed = part.Trim();
                            if (!trimmed.StartsWith("Domain=",
                                    System.StringComparison.OrdinalIgnoreCase))
                            {
                                cleanParts.Add(part);
                            }
                        }
                        var cleanCookie = string.Join(";", cleanParts);
                        // ✅ Use Append not Add — avoids Cookie property warning
                        Response.Headers.Append("Set-Cookie", cleanCookie);
                    }
                }

                return Redirect("/dashboard");
            }
            catch (Exception ex)
            {
                Console.WriteLine("DoLogin error: " + ex.Message);
                return Redirect("/login?error=1");
            }
        }
    }
}