﻿namespace TaskSales.BlazorUI.Models
{
    // ── Employee ─────────────────────────────────────────
    public class EmployeeModel
    {
        public int EmployeeId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Department { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
        public DateTime CreatedDate { get; set; }
    }

    public class CreateEmployeeModel
    {
        public string Name { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Department { get; set; } = string.Empty;
        public string Role { get; set; } = "Employee";
    }

    // ── Task ─────────────────────────────────────────────
    public class TaskModel
    {
        public int TaskId { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Status { get; set; } = "Pending";
        public string Priority { get; set; } = "Medium";
        public int AssignedEmployeeId { get; set; }
        public string? EmployeeName { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    public class CreateTaskModel
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Status { get; set; } = "Pending";
        public string Priority { get; set; } = "Medium";
        public int AssignedEmployeeId { get; set; }
        public DateTime DueDate { get; set; } = DateTime.Today.AddDays(7);
    }

    // ── Sale ──────────────────────────────────────────────
    public class SaleModel
    {
        public int SaleId { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public DateTime SaleDate { get; set; }
        public int EmployeeId { get; set; }
        public string? EmployeeName { get; set; }
    }

    public class CreateSaleModel
    {
        public string ProductName { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public DateTime SaleDate { get; set; } = DateTime.Today;
        public int EmployeeId { get; set; }
    }

    // ── Analytics ─────────────────────────────────────────
    public record SalesSummaryModel(string Category, decimal Total, int Count);
    public record MonthlySalesModel(int Month, string MonthName, decimal Total);
    public record EmployeeSalesModel(string EmployeeName, decimal Total, int Count);

    // ── Auth ─────────────────────────────────────────────
    public class LoginModel
    {
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }

    public class RegisterModel
    {
        public string FullName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string Role { get; set; } = "Employee";
        public string Department { get; set; } = string.Empty;
    }

    public class ActivityLogModel
    {
        public string UserId { get; set; } = string.Empty;
        public string Action { get; set; } = string.Empty;
        public string Module { get; set; } = string.Empty;
        public string Details { get; set; } = string.Empty;
        public DateTime Timestamp { get; set; }
    }
    // ── Reviews ───────────────────────────────────────────────
    public class ReviewModel
    {
        public string Id { get; set; } = string.Empty;
        public int TaskId { get; set; }
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; } = string.Empty;
        public int Rating { get; set; }
        public string Comment { get; set; } = string.Empty;
        public DateTime CreatedDate { get; set; }
    }

    public class AddReviewModel
    {
        public int TaskId { get; set; }
        public int EmployeeId { get; set; }
        public int Rating { get; set; } = 5;
        public string Comment { get; set; } = string.Empty;
    }
}