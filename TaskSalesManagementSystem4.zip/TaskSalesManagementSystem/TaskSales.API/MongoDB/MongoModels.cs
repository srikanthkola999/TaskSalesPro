﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace TaskSales.API.MongoDB
{
    public class ActivityLogDoc
    {
        [BsonId] public ObjectId Id { get; set; }
        public string UserId { get; set; } = string.Empty;
        public string Action { get; set; } = string.Empty;
        public string Module { get; set; } = string.Empty;
        public string Details { get; set; } = string.Empty;
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    }

    public class TaskReviewDoc
    {
        [BsonId] public ObjectId Id { get; set; }
        public int TaskId { get; set; }
        public int EmployeeId { get; set; }
        public int Rating { get; set; }
        public string Comment { get; set; } = string.Empty;
        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
    }

    // API-facing response models
    public class ActivityLogResponse
    {
        public string Id { get; set; } = string.Empty;
        public string UserId { get; set; } = string.Empty;
        public string Action { get; set; } = string.Empty;
        public string Module { get; set; } = string.Empty;
        public string Details { get; set; } = string.Empty;
        public DateTime Timestamp { get; set; }
    }

    public class TaskReviewResponse
    {
        public string Id { get; set; } = string.Empty;
        public int TaskId { get; set; }
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; } = string.Empty; // ← ADD THIS
        public int Rating { get; set; }
        public string Comment { get; set; } = string.Empty;
        public DateTime CreatedDate { get; set; }
    }

    public class AddReviewRequest
    {
        public int TaskId { get; set; }
        public int EmployeeId { get; set; }
        public int Rating { get; set; }
        public string Comment { get; set; } = string.Empty;
    }
}
