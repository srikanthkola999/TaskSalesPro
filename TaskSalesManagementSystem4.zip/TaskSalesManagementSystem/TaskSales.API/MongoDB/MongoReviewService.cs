﻿using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;

namespace TaskSales.API.MongoDB
{
    public interface IMongoReviewService
    {
        Task AddReviewAsync(AddReviewRequest req);
        Task<IEnumerable<TaskReviewResponse>> GetByTaskAsync(int taskId);
    }

    public class MongoReviewService : IMongoReviewService
    {
        private readonly IMongoCollection<TaskReviewDoc> _col;

        public MongoReviewService(IOptions<MongoDbSettings> opts)
        {
            var client = new MongoClient(opts.Value.ConnectionString);
            _col = client.GetDatabase(opts.Value.DatabaseName)
                         .GetCollection<TaskReviewDoc>(opts.Value.ReviewsCollection);
        }

        public async Task AddReviewAsync(AddReviewRequest req)
            => await _col.InsertOneAsync(new TaskReviewDoc
            {
                TaskId = req.TaskId,
                EmployeeId = req.EmployeeId,
                Rating = req.Rating,
                Comment = req.Comment
            });

        public async Task<IEnumerable<TaskReviewResponse>> GetByTaskAsync(int taskId)
        {
            var docs = await _col.Find(x => x.TaskId == taskId).ToListAsync();
            return docs.Select(d => new TaskReviewResponse
            {
                Id = d.Id.ToString(),
                TaskId = d.TaskId,
                EmployeeId = d.EmployeeId,
                Rating = d.Rating,
                Comment = d.Comment,
                CreatedDate = d.CreatedDate
            });
        }
    }
}
