﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace TaskSales.API.MongoDB
{
    public interface IMongoActivityLogService
    {
        Task LogAsync(string userId, string action, string module, string details);
        Task<IEnumerable<ActivityLogResponse>> GetLogsAsync(int limit = 200);
        Task<IEnumerable<ActivityLogResponse>> GetLogsByUserAsync(string userId);
    }

    public class MongoActivityLogService : IMongoActivityLogService
    {
        private readonly IMongoCollection<ActivityLogDoc> _col;

        public MongoActivityLogService(IOptions<MongoDbSettings> opts)
        {
            var client = new MongoClient(opts.Value.ConnectionString);
            _col = client.GetDatabase(opts.Value.DatabaseName)
                         .GetCollection<ActivityLogDoc>(opts.Value.ActivityLogsCollection);
        }

        public async Task LogAsync(string userId, string action, string module, string details)
            => await _col.InsertOneAsync(new ActivityLogDoc
            { UserId = userId, Action = action, Module = module, Details = details });

        public async Task<IEnumerable<ActivityLogResponse>> GetLogsAsync(int limit = 200)
        {
            var docs = await _col.Find(_ => true)
                .SortByDescending(x => x.Timestamp).Limit(limit).ToListAsync();
            return docs.Select(Map);
        }

        public async Task<IEnumerable<ActivityLogResponse>> GetLogsByUserAsync(string userId)
        {
            var docs = await _col.Find(x => x.UserId == userId)
                .SortByDescending(x => x.Timestamp).ToListAsync();
            return docs.Select(Map);
        }

        private static ActivityLogResponse Map(ActivityLogDoc d) => new()
        {
            Id = d.Id.ToString(),
            UserId = d.UserId,
            Action = d.Action,
            Module = d.Module,
            Details = d.Details,
            Timestamp = d.Timestamp
        };
    }
}

