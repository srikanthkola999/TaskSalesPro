﻿namespace TaskSales.API.MongoDB
{
    public class MongoDbSettings
    {
        public string ConnectionString { get; set; } = "mongodb://localhost:27017";
        public string DatabaseName { get; set; } = "TaskSalesDB";
        public string ActivityLogsCollection { get; set; } = "ActivityLogs";
        public string ReviewsCollection { get; set; } = "TaskReviews";
    }
}
