﻿using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using TaskSales.API.Data;
using TaskSales.API.Interfaces;

namespace TaskSales.API.Repositories
{
    public class GenericRepository<T> : IRepository<T> where T : class
    {
        protected readonly ApplicationDbContext _ctx;
        protected readonly DbSet<T> _set;

        public GenericRepository(ApplicationDbContext ctx) { _ctx = ctx; _set = ctx.Set<T>(); }

        public virtual async Task<IEnumerable<T>> GetAllAsync() => await _set.ToListAsync();
        public virtual async Task<T?> GetByIdAsync(int id) => await _set.FindAsync(id);
        public virtual async Task<IEnumerable<T>> FindAsync(Expression<Func<T, bool>> pred)
            => await _set.Where(pred).ToListAsync();

        public virtual async Task<T> AddAsync(T entity)
        { await _set.AddAsync(entity); await _ctx.SaveChangesAsync(); return entity; }

        public virtual async Task UpdateAsync(T entity)
        { _ctx.Entry(entity).State = EntityState.Modified; await _ctx.SaveChangesAsync(); }

        public virtual async Task DeleteAsync(int id)
        { var e = await GetByIdAsync(id); if (e != null) { _set.Remove(e); await _ctx.SaveChangesAsync(); } }
    }
}
