﻿using Microsoft.EntityFrameworkCore;
using TaskSales.API.Data;
using TaskSales.API.Entities;
using TaskSales.API.Interfaces;

namespace TaskSales.API.Repositories
{
    public class TaskRepository : GenericRepository<TaskItem>, ITaskRepository
    {
        public TaskRepository(ApplicationDbContext ctx) : base(ctx) { }

        public override async Task<IEnumerable<TaskItem>> GetAllAsync()
            => await _ctx.Tasks.Include(t => t.AssignedEmployee).ToListAsync();

        public override async Task<TaskItem?> GetByIdAsync(int id)
            => await _ctx.Tasks.Include(t => t.AssignedEmployee)
                               .FirstOrDefaultAsync(t => t.TaskId == id);

        public async Task<IEnumerable<TaskItem>> GetByEmployeeIdAsync(int empId)
            => await _ctx.Tasks.Where(t => t.AssignedEmployeeId == empId)
                               .Include(t => t.AssignedEmployee).ToListAsync();

        public async Task<IEnumerable<TaskItem>> GetByStatusAsync(Entities.AppTaskStatus status)
            => await _ctx.Tasks.Where(t => t.Status == status)
                               .Include(t => t.AssignedEmployee).ToListAsync();

        public async Task<IEnumerable<TaskItem>> GetOverdueTasksAsync()
            => await _ctx.Tasks
                         .Where(t => t.DueDate < DateTime.UtcNow && t.Status != Entities.AppTaskStatus.Completed)
                         .Include(t => t.AssignedEmployee).ToListAsync();
    }
}
