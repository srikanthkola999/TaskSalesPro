﻿using Microsoft.EntityFrameworkCore;
using TaskSales.API.Data;
using TaskSales.API.DTOs;
using TaskSales.API.Entities;
using TaskSales.API.Interfaces;

namespace TaskSales.API.Repositories
{
    public class SaleRepository : GenericRepository<Sale>, ISaleRepository
    {
        private static readonly string[] Months =
            ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

        public SaleRepository(ApplicationDbContext ctx) : base(ctx) { }

        public override async Task<IEnumerable<Sale>> GetAllAsync()
            => await _ctx.Sales.Include(s => s.Employee).ToListAsync();

        public async Task<IEnumerable<Sale>> GetByEmployeeIdAsync(int empId)
            => await _ctx.Sales.Where(s => s.EmployeeId == empId).Include(s => s.Employee).ToListAsync();

        public async Task<IEnumerable<Sale>> GetByCategoryAsync(string cat)
            => await _ctx.Sales.Where(s => s.Category == cat).Include(s => s.Employee).ToListAsync();

        public async Task<decimal> GetTotalSalesByEmployeeAsync(int empId)
            => await _ctx.Sales.Where(s => s.EmployeeId == empId).SumAsync(s => s.Amount);

        public async Task<IEnumerable<SalesSummary>> GetSalesByCategoryAsync()
            => await _ctx.Sales.GroupBy(s => s.Category)
               .Select(g => new SalesSummary(g.Key, g.Sum(s => s.Amount), g.Count()))
               .ToListAsync();

        // AFTER — fetch from DB first, then map month name in memory
        public async Task<IEnumerable<MonthlySalesSummary>> GetMonthlySalesAsync(int year)
        {
            // Step 1 — only translate what SQL understands (no array indexing)
            var raw = await _ctx.Sales
                .Where(s => s.SaleDate.Year == year)
                .GroupBy(s => s.SaleDate.Month)
                .Select(g => new
                {
                    Month = g.Key,
                    Total = g.Sum(s => s.Amount)
                })
                .OrderBy(x => x.Month)
                .ToListAsync();  // hits DB here — safe SQL

            // Step 2 — map month number to name in C# memory (not in SQL)
            return raw.Select(x => new MonthlySalesSummary(x.Month, Months[x.Month], x.Total));
        }

        // AFTER — group by ID only in SQL, join name in memory
        public async Task<IEnumerable<EmployeeSalesSummary>> GetSalesByEmployeeAsync()
        {
            var raw = await _ctx.Sales
                .Include(s => s.Employee)
                .GroupBy(s => s.EmployeeId)
                .Select(g => new
                {
                    EmployeeId = g.Key,
                    Total = g.Sum(s => s.Amount),
                    Count = g.Count(),
                    Name = g.First().Employee!.Name   // safe after Include
                })
                .OrderByDescending(x => x.Total)
                .ToListAsync();

            return raw.Select(x => new EmployeeSalesSummary(x.Name, x.Total, x.Count));
        }
    }
}
