﻿using Microsoft.EntityFrameworkCore;
using TaskSales.API.Data;
using TaskSales.API.Entities;
using TaskSales.API.Interfaces;

namespace TaskSales.API.Repositories
{
    public class EmployeeRepository : GenericRepository<Employee>, IEmployeeRepository
    {
        public EmployeeRepository(ApplicationDbContext ctx) : base(ctx) { }

        public override async Task<IEnumerable<Employee>> GetAllAsync()
            => await _ctx.Employees.Include(e => e.Tasks).Include(e => e.Sales).ToListAsync();

        public async Task<Employee?> GetByEmailAsync(string email)
            => await _ctx.Employees.FirstOrDefaultAsync(e => e.Email == email);

        public async Task<Employee?> GetByUserIdAsync(string userId)
            => await _ctx.Employees.FirstOrDefaultAsync(e => e.UserId == userId);

        public async Task<IEnumerable<Employee>> GetByDepartmentAsync(string dept)
            => await _ctx.Employees.Where(e => e.Department == dept).ToListAsync();
    }
}
