﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using TaskSales.API.Entities;

namespace TaskSales.API.Data
{
    // Custom Identity User — links to Employee record
    public class ApplicationUser : IdentityUser
    {
        public string? FullName { get; set; }
        public int? EmployeeId { get; set; }
    }

    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        public DbSet<Employee> Employees => Set<Employee>();
        public DbSet<TaskItem> Tasks => Set<TaskItem>();
        public DbSet<Sale> Sales => Set<Sale>();

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<Employee>(e => {
                e.HasKey(x => x.EmployeeId);
                e.Property(x => x.Name).IsRequired().HasMaxLength(100);
                e.Property(x => x.Email).IsRequired().HasMaxLength(200);
                e.HasIndex(x => x.Email).IsUnique();
            });

            builder.Entity<TaskItem>(t => {
                t.HasKey(x => x.TaskId);
                t.Property(x => x.Title).IsRequired().HasMaxLength(200);
                t.Property(x => x.Status).HasConversion<string>();
                t.Property(x => x.Priority).HasConversion<string>();
                t.HasOne(x => x.AssignedEmployee)
                 .WithMany(e => e.Tasks)
                 .HasForeignKey(x => x.AssignedEmployeeId)
                 .OnDelete(DeleteBehavior.Restrict);
            });

            builder.Entity<Sale>(s => {
                s.HasKey(x => x.SaleId);
                s.Property(x => x.Amount).HasColumnType("decimal(18,2)");
                s.Property(x => x.ProductName).IsRequired().HasMaxLength(200);
                s.Property(x => x.Category).HasMaxLength(100);
                s.HasOne(x => x.Employee)
                 .WithMany(e => e.Sales)
                 .HasForeignKey(x => x.EmployeeId)
                 .OnDelete(DeleteBehavior.Restrict);
            });
        }
    }
}
