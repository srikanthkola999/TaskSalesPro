﻿namespace TaskSales.API.Entities
{
    public enum AppTaskStatus { Pending, InProgress, Completed, Cancelled }
    public enum AppTaskPriority { Low, Medium, High, Critical }

    public class TaskItem
    {
        public int TaskId { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public AppTaskStatus Status { get; set; } = AppTaskStatus.Pending;
        public AppTaskPriority Priority { get; set; } = AppTaskPriority.Medium;
        public int AssignedEmployeeId { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

        public virtual Employee? AssignedEmployee { get; set; }
    }
}
