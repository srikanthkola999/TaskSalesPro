﻿namespace TaskSales.API.Entities
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Department { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public string? UserId { get; set; }   // links to Identity user

        public virtual ICollection<TaskItem> Tasks { get; set; } = [];
        public virtual ICollection<Sale> Sales { get; set; } = [];
    }
}
