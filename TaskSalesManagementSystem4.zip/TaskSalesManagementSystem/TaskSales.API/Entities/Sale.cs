﻿using System.ComponentModel.DataAnnotations.Schema;

namespace TaskSales.API.Entities
{
    public class Sale
    {
        public int SaleId { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        [Column(TypeName = "decimal(19,2)")]
        public decimal Amount { get; set; }
        public DateTime SaleDate { get; set; } = DateTime.UtcNow;
        public int EmployeeId { get; set; }

        public virtual Employee? Employee { get; set; }
    }
}
