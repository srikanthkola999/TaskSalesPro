﻿using TaskSales.API.Entities;

namespace TaskSales.API.Interfaces
{
    public interface ITaskRepository : IRepository<TaskItem>
    {
        Task<IEnumerable<TaskItem>> GetByEmployeeIdAsync(int employeeId);
        Task<IEnumerable<TaskItem>> GetByStatusAsync(AppTaskStatus status);
        Task<IEnumerable<TaskItem>> GetOverdueTasksAsync();
    }
}
