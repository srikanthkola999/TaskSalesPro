﻿using TaskSales.API.Entities;

namespace TaskSales.API.Interfaces
{
    public interface IEmployeeRepository : IRepository<Employee>
    {
        Task<Employee?> GetByEmailAsync(string email);
        Task<Employee?> GetByUserIdAsync(string userId);
        Task<IEnumerable<Employee>> GetByDepartmentAsync(string department);
    }
}

