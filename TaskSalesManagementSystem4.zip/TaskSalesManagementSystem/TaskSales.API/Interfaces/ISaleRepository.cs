﻿using TaskSales.API.DTOs;
using TaskSales.API.Entities;

namespace TaskSales.API.Interfaces
{
    public interface ISaleRepository : IRepository<Sale>
    {
        Task<IEnumerable<Sale>> GetByEmployeeIdAsync(int employeeId);
        Task<IEnumerable<Sale>> GetByCategoryAsync(string category);
        Task<decimal> GetTotalSalesByEmployeeAsync(int employeeId);
        Task<IEnumerable<SalesSummary>> GetSalesByCategoryAsync();
        Task<IEnumerable<MonthlySalesSummary>> GetMonthlySalesAsync(int year);
        Task<IEnumerable<EmployeeSalesSummary>> GetSalesByEmployeeAsync();
    }
}
