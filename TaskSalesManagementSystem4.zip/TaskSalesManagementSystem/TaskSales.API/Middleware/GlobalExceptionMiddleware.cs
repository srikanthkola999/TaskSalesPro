﻿using System.Net;
using System.Text.Json;

namespace TaskSales.API.Middleware
{
    public class GlobalExceptionMiddleware(RequestDelegate next, ILogger<GlobalExceptionMiddleware> logger)
    {
        public async Task InvokeAsync(HttpContext ctx)
        {
            try { await next(ctx); }
            catch (Exception ex)
            {
                logger.LogError(ex, "Unhandled exception");
                ctx.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                ctx.Response.ContentType = "application/json";
                await ctx.Response.WriteAsync(JsonSerializer.Serialize(
                    new { error = "Internal server error", detail = ex.Message }));
            }
        }
    }
}
