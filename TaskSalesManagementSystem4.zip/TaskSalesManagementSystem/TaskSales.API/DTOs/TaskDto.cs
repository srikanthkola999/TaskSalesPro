﻿using System.ComponentModel.DataAnnotations;
using TaskSales.API.Entities;

namespace TaskSales.API.DTOs
{
    public class TaskDto
    {
        public int TaskId { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;      // ✅ was AppTaskStatus
        public string Priority { get; set; } = string.Empty;    // ✅ was AppTaskPriority
        public int AssignedEmployeeId { get; set; }
        public string? EmployeeName { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    public class CreateTaskDto
    {
        [Required] public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;

        // ✅ Accept as strings — controller parses with Enum.TryParse
        public string Status { get; set; } = "Pending";
        public string Priority { get; set; } = "Medium";

        [Required, Range(1, int.MaxValue, ErrorMessage = "Select an employee")]
        public int AssignedEmployeeId { get; set; }
        [Required] public DateTime DueDate { get; set; }
    }
}
