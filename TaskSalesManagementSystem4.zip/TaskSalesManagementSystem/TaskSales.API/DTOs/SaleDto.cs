﻿using System.ComponentModel.DataAnnotations;

namespace TaskSales.API.DTOs
{
    public class SaleDto
    {
        public int SaleId { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public DateTime SaleDate { get; set; }
        public int EmployeeId { get; set; }
        public string? EmployeeName { get; set; }
    }

    public class CreateSaleDto
    {
        [Required] public string ProductName { get; set; } = string.Empty;
        [Required] public string Category { get; set; } = string.Empty;
        [Required, Range(0.01, double.MaxValue)] public decimal Amount { get; set; }
        [Required] public DateTime SaleDate { get; set; } = DateTime.UtcNow;
        [Required] public int EmployeeId { get; set; }
    }

    public record SalesSummary(string Category, decimal Total, int Count);
    public record MonthlySalesSummary(int Month, string MonthName, decimal Total);
    public record EmployeeSalesSummary(string EmployeeName, decimal Total, int Count);
}
